package com.lec.uitest.dto;

import lombok.Data;

@Data
public class StudentDto {
	private String name;
	private int kor;
	private int eng;
	private int math;
}
